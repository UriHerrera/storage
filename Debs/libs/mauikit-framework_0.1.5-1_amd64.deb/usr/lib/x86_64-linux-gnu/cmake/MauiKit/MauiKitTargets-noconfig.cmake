#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "MauiKit" for configuration ""
set_property(TARGET MauiKit APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(MauiKit PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libMauiKit.so"
  IMPORTED_SONAME_NOCONFIG "libMauiKit.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS MauiKit )
list(APPEND _IMPORT_CHECK_FILES_FOR_MauiKit "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libMauiKit.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
